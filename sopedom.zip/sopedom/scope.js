
// assignment one

document.getElementById("myBtn").addEventListener("click", function(){
	document.getElementById("button1").innerHTML = "Im right";
});


document.getElementById("myBtn2").addEventListener("click", function(){
	document.getElementById("button2").innerHTML = "No, I'm right";
});

// Assignment two
document.getElementById("myBtn").addEventListener("mouseover", function mouseover(){
	document.getElementById("myBtn").innerHTML = "Dont't hover over me";
});

//Assignment three
document.onkeypress = zx();
function zx(e){
var charCode = (typeof e.which == "number") ? e.which : e.keyCode
}

//Assignment four

var passwordcheck = 12345678;
function onSubmit(){
	if (document.getElementById('submit').value == '12345678');
} else {
	alert ('incorrect')
} document.getElementById('head').innerHTML = 'Welcome';

