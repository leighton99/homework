//soundcloud!!

	SC.initialize({
		client_id: "fd4e76fc67798bfa742089ed619084a6"
	});
	console.log("initialize");


//get playlist

SC.get("/playlists/4126213").then(function (player){
	console.log(player);
	player.play();
}); 



// var tracks = ['82235908', '69704083', '81772245']

var tracks = []

//get one song

function Sound() {
	SC.stream( '/tracks/ + tracks[0]').then(function(player){
		console.log(player);
		player.play();
		player.on('finish',function(){
			Sound = 1;
		});
	});
}


//play button

document.getElementById('playbtn').addEventListener('click', function(){
	Sound()
})


//pause button

document.get('pausebtn').addEventListener('click', function(){
	Sound().pause();
})

//stop button


document.getElementById('stopbtn').addEventListener('click', function(){
	Sound().pause();
	Sound().seek(0);
})

//next button



document.getElementById('nextbtn').addEventListener('click', function(){
	playNext();
});

//previous button

// document.getElementById('previousbtn').addEventListener('click', function(){
// 	Sound()
// })


// function Songtitle(){
// 	document.getElementById("title").innerHTML = "";
// }



