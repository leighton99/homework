
//soundcloud!!

// window.onload = function() {
	SC.initialize({
		client_id: "fd4e76fc67798bfa742089ed619084a6"
	});
	console.log("initialize");
// }


//get playlists....

// function Sound() {
// 		songs = ['82235908'],
//     this.song = SC.stream('/tracks' + songs)
// };

// var songs = new Sound();

// Sound.prototype.play = function() {
//     this.song.then(function(player) {
//         player.play();
//     });




SC.get("/playlists/4126213").then(function (player){
	console.log(player);
	player.play();
}); 

//get one song....

var tracks = ['82235908', '69704083', '81772245']
function Sound() {
	SC.stream( '/tracks/69704083').then(function(player){
		console.log(player);
		player.play();
		player.on('finish',function(){
			Sound += 1;
			// playNext();
		});
	});
}


Sound.prototype.pause = function(){
	this.song.then(function(player) {
		player.pause();
	})
}

//get album art...

var button = document.getElementById('pause');

button.addEventListener('click', function(){
	playNext();
});

document.getElementById('play').addEventListener('click', function(){
	Sound()
})

document.getElementById('pause').addEventListener('click', function(){
	Sound()
})
